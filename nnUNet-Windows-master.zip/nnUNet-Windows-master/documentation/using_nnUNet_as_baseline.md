(The U-Net is the current punching bag of methods development. nnU-Net is going to be that looking forward. That is 
cool (great, in fact!), but it should be done correctly. Here are tips on how to benchmark against nnU-Net)

This is work in progress